// Pathway Estate Planning — Process, Services, Soft CTA, Testimonials, Local

function Process() {
  const steps = [
    { icon: <Icon.Bubble />, title: 'A free initial chat', body: 'We talk through your situation. No pressure, no commitment, no jargon.', time: '~45 min' },
    { icon: <Icon.Doc />,    title: 'Your tailored plan', body: "We explain what we'd suggest and why — with clear, agreed costs before you decide.", time: 'Within a week' },
    { icon: <Icon.Pen />,    title: 'Drafting and signing', body: 'We prepare your documents in plain English and guide you through signing.', time: '1–2 weeks' },
    { icon: <Icon.Hands />,  title: 'Ongoing support',   body: "Life changes. We're here when something needs updating or you just want to talk.", time: 'For as long as you need' },
  ];
  const ref = React.useRef(null);
  const [inView, setInView] = React.useState(false);
  React.useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setInView(true); io.disconnect(); } }, { threshold: 0.18 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return (
    <section className={`process ${inView ? 'in-view' : ''}`} id="process" data-screen-label="Process" ref={ref}>
      <div className="container">
        <div className="process__head">
          <h4 style={{ marginBottom: 12 }}>How it works</h4>
          <h2>Four simple steps.</h2>
          <p>The same calm, unhurried process whether you're writing a first will or planning across generations.</p>
        </div>
        <div className="process__grid">
          {steps.map((s, i) => (
            <div className="step" key={i}>
              <div className="step__head">
                <div className="step__num">{String(i + 1).padStart(2, '0')}</div>
                <span className="step__icon">{React.cloneElement(s.icon, { width: 28, height: 28 })}</span>
              </div>
              <h3>{s.title}</h3>
              <p>{s.body}</p>
              <span className="step__time">{s.time}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    { icon: <Icon.Doc />,    title: 'Wills',                       body: 'Make sure your wishes are clearly recorded and legally sound.' },
    { icon: <Icon.Shield />, title: 'Trusts',                      body: 'Protect assets for children, vulnerable family, or future generations.' },
    { icon: <Icon.People />, title: 'Lasting Powers of Attorney',  body: "Choose who makes decisions for you if you ever can't." },
    { icon: <Icon.Pie />,    title: 'Inheritance Tax Planning',    body: 'Reduce what HMRC takes and leave more to the people you love.' },
    { icon: <Icon.Heart />,  title: 'Care Planning',               body: 'Plan ahead, honestly, so you and your family understand your options.' },
    { icon: <Icon.Brief />,  title: 'Business Protection',         body: "Keep your business in safe hands, whatever happens." },
    { icon: <Icon.Tractor />,title: 'Agricultural Estate Planning',body: 'Pass land and farming assets to the next generation, properly.' },
  ];
  return (
    <section id="services" data-screen-label="Services">
      <div className="container">
        <div className="services__head">
          <h4 style={{ marginBottom: 12 }}>What we help with</h4>
          <h2>The full range, handled by one person.</h2>
          <p>Each service is offered on its own or as part of a plan that ties them together.</p>
        </div>
        <div className="services__grid">
          {services.map((s, i) => (
            <a className="service" href="#" key={i}>
              <span className="service__icon">{React.cloneElement(s.icon, { width: 30, height: 30 })}</span>
              <h3>{s.title}</h3>
              <p>{s.body}</p>
              <span className="service__arrow">Learn more <Icon.ArrowRight width="14" height="14" /></span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function SoftCTA({ onBook }) {
  return (
    <div className="softcta" data-screen-label="Soft CTA">
      <div className="container">
        <p>
          Not sure what you need?
          <a href="#" onClick={(e) => { e.preventDefault(); onBook(); }}>
            Start with a free chat. <Icon.ArrowRight width="14" height="14" style={{ verticalAlign: 'middle' }} />
          </a>
        </p>
      </div>
    </div>
  );
}

function Testimonials() {
  const items = [
    { theme: 'Confusion', quote: 'They explained everything so clearly. We finally feel like things are in order — and that we understand them.', name: 'Margaret', town: 'Leamington Spa' },
    { theme: 'Trust', quote: 'Patient, professional, and never once made us feel rushed or pressured. We knew exactly what we were paying for.', name: 'David', town: 'Warwick' },
    { theme: 'Family stress', quote: 'Took a real weight off our shoulders. A difficult subject made manageable, with kindness throughout.', name: 'The Hollis family', town: 'Stratford-upon-Avon' },
    { theme: 'Cost', quote: 'Honest about what we did and didn\u2019t need. We came away spending less than expected, with more confidence than we\u2019d had in years.', name: 'Patrick', town: 'Kenilworth' },
    { theme: 'Care fees', quote: 'Cut through the noise about care fee schemes and gave us a straight answer. Refreshing.', name: 'Sarah & Tom', town: 'Southam' },
    { theme: 'Complexity', quote: 'We had a blended family and a farm. Felt completely out of our depth. They walked us through every part of it without ever making us feel small.', name: 'The Whitmore family', town: 'Warwickshire' },
  ];
  // Duplicate for seamless marquee loop
  const loop = [...items, ...items];
  return (
    <section data-screen-label="Testimonials">
      <div className="container">
        <div className="testimonials__head">
          <h4 style={{ marginBottom: 12 }}>What our clients say</h4>
          <h2>Quiet confidence, in their own words.</h2>
        </div>
      </div>
      <div className="testimonials__viewport" tabIndex="0" aria-label="Client testimonials carousel — hover to pause">
        <div className="testimonials__track">
          {loop.map((t, i) => (
            <figure className="testimonial" key={i} aria-hidden={i >= items.length ? 'true' : 'false'}>
              <span className="testimonial__theme">On {t.theme.toLowerCase()}</span>
              <blockquote className="testimonial__quote">{t.quote}</blockquote>
              <div className="testimonial__stars" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }).map((_, j) => <Icon.Star key={j} width="14" height="14" />)}
              </div>
              <figcaption className="testimonial__attr">{t.name}, {t.town}</figcaption>
            </figure>
          ))}
        </div>
      </div>
      <div className="container">
        <p className="testimonials__link"><a href="#">Read more reviews on Google <Icon.ArrowRight width="14" height="14" style={{ verticalAlign: 'middle' }} /></a></p>
      </div>
    </section>
  );
}

function LocalTrust() {
  return (
    <section id="about" data-screen-label="Local">
      <div className="container">
        <div className="local">
          <div className="local__copy">
            <h4 style={{ marginBottom: 16 }}>Where we work</h4>
            <h2>Based in Leamington Spa.<br />Visiting families across Warwickshire.</h2>
            <p style={{ marginTop: 20 }}>
              We meet at our office, in clients' homes, or wherever feels most comfortable.
              Many of the families we work with prefer a kitchen-table conversation to a
              formal meeting room — and that's exactly how we like to work too.
            </p>
            <p>If travel or mobility is an issue, we'll come to you.</p>
            <div style={{ marginTop: 24, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              {['Leamington Spa', 'Warwick', 'Kenilworth', 'Stratford-upon-Avon', 'Southam', 'Rugby'].map(t => (
                <span key={t} style={{
                  fontSize: 13, padding: '8px 14px', borderRadius: 999,
                  border: '1px solid var(--hairline)', color: 'var(--stone)',
                }}>{t}</span>
              ))}
            </div>
          </div>
          <div className="local__visual">
            <image-slot
              id="local-photo"
              shape="rect"
              placeholder="Office exterior, a Georgian door, or a Warwickshire detail — daylight, soft, real."
            ></image-slot>
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Process, Services, SoftCTA, Testimonials, LocalTrust });
