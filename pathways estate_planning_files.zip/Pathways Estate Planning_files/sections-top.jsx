// Pathway Estate Planning — Header, Hero, Trust bar, Problem, Why

function Header({ onBook }) {
  const [scrolled, setScrolled] = React.useState(false);
  const [openMenu, setOpenMenu] = React.useState(null);
  const [navOpen, setNavOpen] = React.useState(false);
  const navRef = React.useRef(null);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  React.useEffect(() => {
    const onDoc = (e) => { if (navRef.current && !navRef.current.contains(e.target)) setOpenMenu(null); };
    const onKey = (e) => { if (e.key === 'Escape') setOpenMenu(null); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, []);
  const toggle = (k) => setOpenMenu(openMenu === k ? null : k);
  const close = () => { setOpenMenu(null); setNavOpen(false); };
  React.useEffect(() => {
    document.body.style.overflow = navOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [navOpen]);
  return (
    <header className={`header ${scrolled ? 'is-scrolled' : ''}`} data-screen-label="Header">
      <div className="header__inner">
        <Logo />
        <nav className={`nav ${navOpen ? 'is-open' : ''}`} aria-label="Primary" ref={navRef}>
          <a href="#" className="nav__link" onClick={close}>Home</a>
          <div className={`nav__item ${openMenu === 'services' ? 'is-open' : ''}`}>
            <button className={`nav__link ${openMenu === 'services' ? 'is-open' : ''}`} onClick={() => toggle('services')} aria-haspopup="true" aria-expanded={openMenu === 'services'}>
              Services <Icon.Chev className="nav__chev" />
            </button>
            <div className="nav__dropdown" role="menu">
              <a href="#services" className="nav__drop-item" onClick={close}>Wills <small>A clear plan, properly drafted.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Trusts <small>Protect what matters most.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Lasting Powers of Attorney <small>Choose who decides if you can't.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Inheritance Tax Planning <small>Reduce what HMRC takes.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Care Planning <small>Plan ahead, honestly.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Business Protection <small>Continuity for what you've built.</small></a>
              <a href="#services" className="nav__drop-item" onClick={close}>Agricultural Estate Planning <small>Land, generations, and succession.</small></a>
            </div>
          </div>
          <a href="#process" className="nav__link" onClick={close}>How It Works</a>
          <a href="#about" className="nav__link" onClick={close}>About</a>
          <div className={`nav__item ${openMenu === 'resources' ? 'is-open' : ''}`}>
            <button className={`nav__link ${openMenu === 'resources' ? 'is-open' : ''}`} onClick={() => toggle('resources')} aria-haspopup="true" aria-expanded={openMenu === 'resources'}>
              Resources <Icon.Chev className="nav__chev" />
            </button>
            <div className="nav__dropdown" role="menu">
              <a href="#faq" className="nav__drop-item" onClick={close}>FAQ <small>Honest answers to common questions.</small></a>
              <a href="#" className="nav__drop-item" onClick={close}>Guides <small>Plain-English explanations.</small></a>
              <a href="#" className="nav__drop-item" onClick={close}>Glossary <small>What the legal terms actually mean.</small></a>
            </div>
          </div>
          <a href="#contact" className="nav__link" onClick={close}>Contact</a>
        </nav>
        <div className="header__cta">
          <button className="btn btn--primary btn--sm" onClick={onBook}>
            <Icon.Calendar className="btn__icon" /> Book free chat
          </button>
          <button className="nav__toggle" aria-label={navOpen ? 'Close menu' : 'Open menu'} aria-expanded={navOpen} onClick={() => setNavOpen(!navOpen)}>
            {navOpen ? (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M6 6l12 12M18 6l-12 12" /></svg>
            ) : (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}

function Hero({ onBook, palette }) {
  return (
    <section className="hero" data-screen-label="Hero">
      <div className="container hero__copy">
        <h1>
          Protect your family<br />from <em>uncertainty.</em>
        </h1>
        <p className="hero__sub">
          Wills, trusts, lasting powers of attorney and care planning — explained
          simply, tailored to your family, handled with care.
        </p>
        <div className="hero__ctas">
          <button className="btn btn--primary btn--lg" onClick={onBook}>
            <Icon.Calendar className="btn__icon" /> Book your free initial chat
          </button>
          <a href="tel:01926123456" className="btn btn--ghost btn--lg">
            <Icon.Phone className="btn__icon" /> Call 01926 123 456
          </a>
        </div>
        <div className="hero__assure">
          <Icon.Check width="18" height="18" />
          <span>No obligation. No jargon. Home visits available across Warwickshire.</span>
        </div>
      </div>
      <div className="hero__visual" aria-hidden="false">
        <image-slot
          id="hero-photo"
          shape="rect"
          placeholder="Hero photo — a family in the Warwickshire countryside, kitchen-table moment, or a calm interior detail. Real, not stock."
        ></image-slot>
      </div>
    </section>
  );
}

function TrustBar() {
  const items = [
    { icon: <Icon.Shield />, text: "Nearly 20 years' experience" },
    { icon: <Icon.Award />, text: 'Fully qualified and insured' },
    { icon: <Icon.Pin />,    text: 'Local to Leamington Spa' },
    { icon: <Icon.Home />,   text: 'Home visits available' },
  ];
  return (
    <div className="trustbar">
      <div className="trustbar__inner">
        {items.map((it, i) => (
          <div className="trust" key={i}>
            <span className="trust__icon">{React.cloneElement(it.icon, { width: 18, height: 18 })}</span>
            <span>{it.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProblemSection() {
  const problems = [
    'Long delays before family can access money or property',
    'Decisions made by courts rather than by you',
    'Inheritance tax that could have been reduced',
    'Disputes between relatives about what you would have wanted',
    'Care costs that quietly erode everything you’ve built',
  ];
  return (
    <section className="problem-section" data-screen-label="Problem">
      <div className="container">
        <div className="problem">
          <h4>The cost of doing nothing</h4>
          <h2>Without a plan, your family is left to guess.</h2>
          <p className="problem__lede">
            When nothing is in place, the people you love are the ones who deal
            with the consequences — often at the hardest possible time.
          </p>
          <p className="problem__intro">Without clear planning, families can face:</p>
          <ul className="problem__list">
            {problems.map((p, i) => (
              <li key={i}>
                <span className="check"><Icon.Check width="12" height="12" /></span>
                <span>{p}</span>
              </li>
            ))}
          </ul>
          <p className="problem__close">
            “A clear plan, made in advance, protects the people you care about from all of it.”
          </p>
        </div>
      </div>
    </section>
  );
}

function WhySection() {
  const why = [
    { icon: <Icon.People />, title: 'Genuinely personal',
      body: "You'll deal with the same person from your first chat to the final document. No call centres, no handovers." },
    { icon: <Icon.Shield />, title: 'Properly experienced',
      body: 'Nearly two decades helping families across Warwickshire — from straightforward wills to complex estates.' },
    { icon: <Icon.Bubble />, title: 'Always clear',
      body: "We won't bury you in legal terms or surprise you with costs. If something isn't right for you, we'll say so." },
  ];
  return (
    <section className="why-section section--cream" data-screen-label="Why">
      <div className="container">
        <div className="why__head">
          <h4>Why families choose us</h4>
          <h2>The reassurance of one person, start to finish.</h2>
        </div>
        <div className="why__grid">
          {why.map((w, i) => (
            <div className="why__card" key={i}>
              <div className="why__icon">{React.cloneElement(w.icon, { width: 24, height: 24 })}</div>
              <h3>{w.title}</h3>
              <p>{w.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Header, Hero, TrustBar, ProblemSection, WhySection });
