// Pathway Estate Planning — App composition + Tweaks

const TWEAKS_DEFAULTS = /*EDITMODE-BEGIN*/{
  "headline": "Protect your family from <em>uncertainty.</em>",
  "ctaLabel": "Book your free initial chat",
  "heroLayout": "split",
  "accent": "blue",
  "showSticky": true
}/*EDITMODE-END*/;

const ACCENTS = {
  blue:  { sage: '#2F4D7A', deep: '#1F3559', light: '#DCE6F2' },
  sage:  { sage: '#5C7159', deep: '#3F5040', light: '#E4EADD' },
  ink:   { sage: '#1F3A2E', deep: '#10221A', light: '#E0E6E1' },
  clay:  { sage: '#B8744D', deep: '#8E5535', light: '#F4E2D5' },
};

function App() {
  const [bookOpen, setBookOpen] = React.useState(false);
  const t = useTweaks ? useTweaks(TWEAKS_DEFAULTS) : { tweaks: TWEAKS_DEFAULTS, setTweak: () => {} };
  const tweaks = t.tweaks || TWEAKS_DEFAULTS;

  // Apply accent
  React.useEffect(() => {
    const a = ACCENTS[tweaks.accent] || ACCENTS.sage;
    document.documentElement.style.setProperty('--sage', a.sage);
    document.documentElement.style.setProperty('--sage-deep', a.deep);
    document.documentElement.style.setProperty('--sage-light', a.light);
  }, [tweaks.accent]);

  const onBook = React.useCallback(() => setBookOpen(true), []);

  return (
    <React.Fragment>
      <a href="#main" className="sr-only">Skip to content</a>
      <Header onBook={onBook} />
      <main id="main">
        <HeroVariant onBook={onBook} tweaks={tweaks} />
        <TrustBar />
        <ProblemSection />
        <WhySection />
        <Process />
        <Services />
        <SoftCTA onBook={onBook} />
        <Testimonials />
        <LocalTrust />
        <FAQ onBook={onBook} />
        <Newsletter />
        <FinalCTA onBook={onBook} />
      </main>
      <Footer />
      {tweaks.showSticky && <MobileSticky onBook={onBook} />}
      <BookingModal open={bookOpen} onClose={() => setBookOpen(false)} />

      <TweaksPanel title="Tweaks">
        <TweakSection title="Hero">
          <TweakText label="Headline (supports <em>)" value={tweaks.headline} onChange={(v) => t.setTweak('headline', v)} />
          <TweakRadio label="Hero layout"
            value={tweaks.heroLayout}
            options={[{value:'split',label:'Split'},{value:'centered',label:'Centred'}]}
            onChange={(v) => t.setTweak('heroLayout', v)} />
          <TweakText label="Primary CTA label" value={tweaks.ctaLabel} onChange={(v) => t.setTweak('ctaLabel', v)} />
        </TweakSection>
        <TweakSection title="Palette">
          <TweakColor label="Accent"
            value={tweaks.accent}
            options={[
              {value:'blue', color:'#2F4D7A'},
              {value:'sage', color:'#5C7159'},
              {value:'ink', color:'#1F3A2E'},
              {value:'clay', color:'#B8744D'},
            ]}
            onChange={(v) => t.setTweak('accent', v)} />
        </TweakSection>
        <TweakSection title="Mobile">
          <TweakToggle label="Show sticky CTA bar"
            value={tweaks.showSticky}
            onChange={(v) => t.setTweak('showSticky', v)} />
        </TweakSection>
        <TweakSection title="Try it">
          <TweakButton onClick={onBook}>Open booking dialog</TweakButton>
        </TweakSection>
      </TweaksPanel>
    </React.Fragment>
  );
}

// Hero with layout switch
function HeroVariant({ onBook, tweaks }) {
  if (tweaks.heroLayout === 'centered') {
    return (
      <section className="hero" style={{ gridTemplateColumns: '1fr', minHeight: 'auto' }} data-screen-label="Hero">
        <div className="container hero__copy" style={{ padding: '120px 32px 96px', justifySelf: 'center', textAlign: 'center', maxWidth: 880 }}>
          <h1 dangerouslySetInnerHTML={{ __html: tweaks.headline }} />
          <p className="hero__sub" style={{ margin: '24px auto 32px' }}>
            Wills, trusts, lasting powers of attorney and care planning — explained
            simply, tailored to your family, handled with care.
          </p>
          <div className="hero__ctas" style={{ justifyContent: 'center' }}>
            <button className="btn btn--primary btn--lg" onClick={onBook}>
              <Icon.Calendar className="btn__icon" /> {tweaks.ctaLabel}
            </button>
            <a href="tel:01926123456" className="btn btn--ghost btn--lg">
              <Icon.Phone className="btn__icon" /> Call 01926 123 456
            </a>
          </div>
        </div>
      </section>
    );
  }
  return (
    <section className="hero" data-screen-label="Hero">
      <div className="container hero__copy">
        <h1 dangerouslySetInnerHTML={{ __html: tweaks.headline }} />
        <p className="hero__sub">
          Wills, trusts, lasting powers of attorney and care planning — explained
          simply, tailored to your family, handled with care.
        </p>
        <div className="hero__ctas">
          <button className="btn btn--primary btn--lg" onClick={onBook}>
            <Icon.Calendar className="btn__icon" /> {tweaks.ctaLabel}
          </button>
          <a href="tel:01926123456" className="btn btn--ghost btn--lg">
            <Icon.Phone className="btn__icon" /> Call 01926 123 456
          </a>
        </div>
        <div className="hero__assure">
          <Icon.Check width="18" height="18" />
          <span>No obligation. No jargon. Home visits available across Warwickshire.</span>
        </div>
      </div>
      <div className="hero__visual" aria-hidden="false">
        <image-slot
          id="hero-photo"
          shape="rect"
          placeholder="Hero photo — a family in the Warwickshire countryside, or a kitchen-table moment. Real, not stock."
        ></image-slot>
      </div>
    </section>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
