// Pathway Estate Planning — FAQ, Final CTA, Footer, Booking modal, Mobile sticky

function FAQ({ onBook }) {
  const items = [
    {
      q: 'Do I really need a will if I’m married?',
      a: "Yes — a common misconception is that everything passes to your spouse automatically. In England and Wales, the intestacy rules can divide your estate in ways that surprise families. A simple will makes your wishes clear.",
    },
    {
      q: 'How much does estate planning cost?',
      a: "We agree fixed costs with you before any work begins. A straightforward will starts from around £195. More involved planning is priced after a free chat — you only proceed once you've seen the figure and said yes.",
    },
    {
      q: 'What’s the difference between a will and a trust?',
      a: "A will sets out your wishes when you die. A trust is a structure that holds assets — sometimes during your lifetime, sometimes after — to protect them for someone or reduce tax. Many estates use both.",
    },
    {
      q: 'How does care planning work?',
      a: "We help you understand how care is paid for, what local authorities can and can't take into account, and the legitimate planning options available. We're also honest about schemes that don't work — see our note on care fee \u2018trusts’.",
    },
    {
      q: 'How long does the whole process take?',
      a: "A straightforward will is usually drafted within a week of our second meeting. More complex planning takes longer — we agree the timeline with you up front so there are no surprises.",
    },
    {
      q: 'What happens at the free initial chat?',
      a: "About 45 minutes, in person or by phone. We listen first — what's prompted you to think about this, what you're worried about, what's already in place. You leave with a clearer view, whether or not we end up working together.",
    },
  ];
  const [open, setOpen] = React.useState(0);
  return (
    <section id="faq" data-screen-label="FAQ">
      <div className="container">
        <div className="faq__head">
          <h4 style={{ marginBottom: 12 }}>Common questions</h4>
          <h2>Honest answers to what families ask first.</h2>
        </div>
        <div className="faq__list">
          {items.map((it, i) => (
            <div className={`faq__item ${open === i ? 'open' : ''}`} key={i}>
              <button
                className="faq__btn"
                onClick={() => setOpen(open === i ? -1 : i)}
                aria-expanded={open === i}
              >
                <span>{it.q}</span>
                <span className="faq__icon"><Icon.Plus width="16" height="16" /></span>
              </button>
              <div className="faq__answer" role="region">
                <p>{it.a}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="faq__see-all"><a href="#">See all questions <Icon.ArrowRight width="14" height="14" style={{ verticalAlign: 'middle' }} /></a></p>
      </div>
    </section>
  );
}

function Newsletter() {
  const [email, setEmail] = React.useState('');
  const [done, setDone] = React.useState(false);
  return (
    <section className="newsletter" data-screen-label="Newsletter">
      <div className="newsletter__inner">
        <div>
          <h4 style={{ marginBottom: 12 }}>Stay in touch</h4>
          <h2>Plain‑English guides, <em style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', color: 'var(--sage)' }}>once a month.</em></h2>
          <p style={{ marginTop: 12, maxWidth: '42ch' }}>Practical notes on wills, trusts and care planning — no jargon, no sales. Unsubscribe any time.</p>
        </div>
        <form className="newsletter__form-wrap" onSubmit={(e) => { e.preventDefault(); setDone(true); }}>
          {done ? (
            <div style={{ padding: '14px 18px', background: 'var(--sage-light)', borderRadius: 10, color: 'var(--sage-deep)', fontWeight: 500 }}>
              Thank you — please check your inbox to confirm.
            </div>
          ) : (
            <React.Fragment>
              <div className="newsletter__form">
                <input type="email" required placeholder="Your email address" value={email} onChange={(e) => setEmail(e.target.value)} aria-label="Email address" />
                <button type="submit" className="btn btn--primary">Sign up</button>
              </div>
              <p className="newsletter__note">We never share your details.</p>
            </React.Fragment>
          )}
        </form>
      </div>
    </section>
  );
}

function FinalCTA({ onBook }) {
  return (
    <section className="finalcta" id="contact" data-screen-label="Final CTA">
      <div className="container">
        <h4 style={{ color: 'var(--sage)', marginBottom: 18 }}>Take the first step</h4>
        <h2>Start with a free, no-obligation chat.</h2>
        <p>
          Most people leave their first conversation with us feeling lighter —
          clearer about what they need, and reassured that it's more straightforward
          than they expected.
        </p>
        <div className="finalcta__ctas">
          <button className="btn btn--primary btn--lg" onClick={onBook}>
            <Icon.Calendar className="btn__icon" /> Book your free initial chat
          </button>
          <a className="btn btn--ghost btn--lg" href="tel:01926123456">
            <Icon.Phone className="btn__icon" /> Call 01926 123 456
          </a>
        </div>
        <p className="finalcta__phone">
          Happy to talk things through on the phone first — Mon–Fri, 9–5.
        </p>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer" data-screen-label="Footer">
      <div className="container">
        <div className="footer__grid">
          <div className="footer__brand">
            <Logo />
            <p>Clear, practical estate planning for individuals and families across Warwickshire. Handled with care.</p>
          </div>
          <div>
            <h4>Services</h4>
            <ul>
              <li><a href="#">Wills</a></li>
              <li><a href="#">Trusts</a></li>
              <li><a href="#">Lasting Powers of Attorney</a></li>
              <li><a href="#">Inheritance Tax Planning</a></li>
              <li><a href="#">Care Planning</a></li>
              <li><a href="#">Business Protection</a></li>
              <li><a href="#">Agricultural</a></li>
            </ul>
          </div>
          <div>
            <h4>Resources</h4>
            <ul>
              <li><a href="#">How It Works</a></li>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Helpful guides</a></li>
              <li><a href="#">Glossary</a></li>
              <li><a href="#">About</a></li>
              <li><a href="#">Complaints</a></li>
            </ul>
          </div>
          <div>
            <h4>Contact</h4>
            <div className="footer__contact-row"><Icon.Phone width="14" height="14" /><span>01926 123 456</span></div>
            <div className="footer__contact-row"><Icon.Mail width="14" height="14" /><span>hello@<br/>pathwayestateplanning.co.uk</span></div>
            <div className="footer__contact-row"><Icon.Pin width="14" height="14" /><span>12 Regent Grove<br/>Leamington Spa<br/>Warwickshire CV32 4NN</span></div>
            <div style={{ marginTop: 14, fontSize: 13, color: 'rgba(250,248,244,0.5)' }}>Mon–Fri, 9–5</div>
          </div>
          <div>
            <h4>We are regulated</h4>
            <div className="footer__regulated">
              Pathway Estate Planning is qualified, insured, and a member of the Society of Will Writers.
              <div className="footer__cred">SWW reg. 22—1948</div>
            </div>
          </div>
        </div>
        <div className="footer__bottom">
          <span>© 2026 Pathway Estate Planning. All rights reserved.</span>
          <div className="footer__legal">
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
            <a href="#">Cookies</a>
            <a href="#">Complaints</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function BookingModal({ open, onClose }) {
  const [submitted, setSubmitted] = React.useState(false);
  const [data, setData] = React.useState({ name: '', phone: '', email: '', when: 'morning', note: '' });
  React.useEffect(() => {
    if (!open) { setSubmitted(false); setData({ name: '', phone: '', email: '', when: 'morning', note: '' }); }
    const onKey = (e) => { if (e.key === 'Escape' && open) onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal__card" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="Book a free initial chat">
        <button className="modal__close" onClick={onClose} aria-label="Close"><Icon.Close width="20" height="20" /></button>
        {submitted ? (
          <div className="success">
            <div className="success__icon"><Icon.Check width="28" height="28" /></div>
            <h3>Thank you, {data.name.split(' ')[0] || 'we’ve got it'}.</h3>
            <p className="modal__lede">We’ll be in touch within one working day to confirm a time that suits you. No pressure, no obligation.</p>
            <button className="btn btn--ghost" onClick={onClose}>Close</button>
          </div>
        ) : (
          <form className="form" onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}>
            <h3>Book your free initial chat</h3>
            <p className="modal__lede">About 45 minutes — in person, by phone, or video. We’ll listen, you’ll leave with a clearer view.</p>
            <div className="field">
              <label htmlFor="bk-name">Your name</label>
              <input id="bk-name" required value={data.name} onChange={e => setData({ ...data, name: e.target.value })} />
            </div>
            <div className="field__row">
              <div className="field">
                <label htmlFor="bk-phone">Phone</label>
                <input id="bk-phone" type="tel" required value={data.phone} onChange={e => setData({ ...data, phone: e.target.value })} />
              </div>
              <div className="field">
                <label htmlFor="bk-email">Email</label>
                <input id="bk-email" type="email" required value={data.email} onChange={e => setData({ ...data, email: e.target.value })} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="bk-when">Preferred time</label>
              <select id="bk-when" value={data.when} onChange={e => setData({ ...data, when: e.target.value })}>
                <option value="morning">Weekday mornings</option>
                <option value="afternoon">Weekday afternoons</option>
                <option value="evening">Early evenings</option>
                <option value="weekend">Weekends</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="bk-note">Anything you’d like us to know? <span style={{ color: 'var(--stone)', fontWeight: 400 }}>(optional)</span></label>
              <textarea id="bk-note" rows="3" value={data.note} onChange={e => setData({ ...data, note: e.target.value })} placeholder="e.g. “We’ve just had a baby and want to sort wills and guardians.”" />
            </div>
            <div className="form__assure">
              <Icon.Lock width="14" height="14" /> Your details stay with the practice. We never share them.
            </div>
            <button type="submit" className="btn btn--primary btn--lg form__submit">
              <Icon.Calendar className="btn__icon" /> Request a free chat
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

function MobileSticky({ onBook }) {
  const [visible, setVisible] = React.useState(false);
  const [dismissed, setDismissed] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  if (dismissed) return null;
  return (
    <div className={`mobile-cta ${visible ? 'is-visible' : ''}`}>
      <div className="mobile-cta__inner">
        <button className="btn btn--primary" onClick={onBook}>
          <Icon.Calendar className="btn__icon" /> Book free chat
        </button>
        <a className="btn btn--ghost" href="tel:01926123456" aria-label="Call">
          <Icon.Phone className="btn__icon" />
        </a>
        <button className="mobile-cta__close" onClick={() => setDismissed(true)} aria-label="Dismiss"><Icon.Close width="16" height="16" /></button>
      </div>
    </div>
  );
}

Object.assign(window, { FAQ, FinalCTA, Footer, BookingModal, MobileSticky, Newsletter });
